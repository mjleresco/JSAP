public function get(url, data, callback){
    $.ajax({
        type: 'GET',
        url: url,
        data: data,
        success: function(response) {
            console.log(response);
        }
    });
    
}

public function post(url, data, callback){
    $.ajax({
        type: 'POST',
        url: url,
        data: data,
        success: function(response) {
            console.log(response);
        }
    });
    
}
