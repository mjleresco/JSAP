<?php

namespace Fust\PHP\Core;

class View
{
    public function render($view, $data = [])
    {
        extract($data);
        require __DIR__ . '/../../../app/Views/' . str_replace('.', '/', $view) . '.php';
    }
}

?>