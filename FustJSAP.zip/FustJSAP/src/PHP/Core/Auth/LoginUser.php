<?php

// User registration example
function registerUser($username, $password, $pdo) {
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Assume $pdo is a PDO instance connected to your database
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->execute();
}

// User login example
function loginUser($username, $password, $pdo) {
    // Fetch the hashed password from the database
    $stmt = $pdo->prepare("SELECT password FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result && password_verify($password, $result['password'])) {
        echo 'Login successful!';
        // Set session variables or other login actions
    } else {
        echo 'Invalid username or password.';
    }
}

?>