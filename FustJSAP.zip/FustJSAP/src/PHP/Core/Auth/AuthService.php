<?php

namespace Fust\Core\Auth;

use Fust\Core\DatabaseUtils;
use Fust\Core\UserUtils;

class AuthService {
    protected $dbUtils;

    public function __construct(DatabaseUtils $dbUtils) {
        $this->dbUtils = $dbUtils;
    }

    public function register($table, $username, $password, $email) {
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Create new user
        $this->dbUtils->insert($table, [
            'username' => $username,
            'password' => $hashedPassword,
            'email' => $email
        ]);

        // Assign default role to user
        $this->dbUtils->insert('user_roles', [
            'user_id' => $this->dbUtils->getLastInsertId(),
            'role' => 'user'
        ]);
    }

    public static function authenticate($url) {
        UserUtils::authenticate($url);
    }

    public function authorize($userId, $role) {
        // Check if user has the specified role
        $userRole = $this->dbUtils->selectOne('user_roles', ['user_id' => $userId, 'role' => $role]);

        return $userRole !== null;
    }
}

?>