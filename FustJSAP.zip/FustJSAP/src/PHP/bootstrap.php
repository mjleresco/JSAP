<?php

// Load Composer's autoloader
require __DIR__ . '/../../vendor/autoload.php';
/*
// Load environment variables from .env file
if (file_exists(__DIR__ . '/../.env')) {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
    $dotenv->load();
}
*/
// Error reporting
//error_reporting(E_ALL);
//ini_set('display_errors', getenv('APP_DEBUG') === 'true' ? '1' : '0');

require __DIR__ . '/Core/Application.php';
require __DIR__ . '/Core/Router.php';
require __DIR__ . '/Core/Request.php';
require __DIR__ . '/Core/Database.php';

// Load helpers
require __DIR__ . '/Utils/UserUtils.php';

// Initialize the application
$app = new \Fust\PHP\Core\Application();

// Load routes
require __DIR__ . '/../../app/routes.php';
use Fust\PHP\Core\Config;

$config = new Config(__DIR__.'/../../config/config.php');
//$this->databaseUtils = new DatabaseUtils(Database::getInstance($config->__get('database')));
// Load core classes
if($config->__get('app')['use-default-admin']){
    require __DIR__ . '/Core/admin/AdminController.php';
    require __DIR__ . '/Core/admin/AdminUser.php';
    require __DIR__ . '/Core/admin/routes.php';
}

// Handle the request and send the response
$app->run();

?>