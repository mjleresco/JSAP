<?php

// Load the bootstrap file to initialize the framework
require __DIR__ . '/../src/PHP/bootstrap.php';

?>

