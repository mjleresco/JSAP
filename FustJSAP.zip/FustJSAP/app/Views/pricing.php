<?php

require __DIR__.'/../../src/Utils/AirtimeUtils.php';
require __DIR__.'/../../src/Utils/DataUtils.php';

use Fust\Utils\PaystackAirtimeProvider;
use Fust\Utils\FlutterwaveDataProvider;
use Fust\Utils\AirtimeUtils;
use Fust\Utils\DataUtils;

$config = include __DIR__.'/../../config/config.php';

// Airtime Pricing
$paystackAirtimeProvider = new PaystackAirtimeProvider($config['paystack']['api_key']);
$airtimeUtils = new AirtimeUtils($paystackAirtimeProvider);
$airtimePricing = $airtimeUtils->getPricing();

// Data Pricing
$flutterwaveDataProvider = new \Fust\Utils\FlutterwaveDataProvider($config['flutterwave']['api_key']);
$dataUtils = new DataUtils($flutterwaveDataProvider);
$dataPricing = $dataUtils->getPricing();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Pricing</title>
</head>
<body>
    <h1>Airtime Pricing</h1>
    <table border="1">
        <tr>
            <th>Plan Name</th>
            <th>Amount</th>
            <th>Interval</th>
        </tr>
        <?php foreach ($airtimePricing['data'] as $plan): ?>
            <tr>
<td><?php echo $plan['name']; ?></td>
<td><?php echo $plan['amount'] / 100; ?> NGN</td>
<td><?php echo $plan['interval']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h1>Data Pricing</h1>
    <table border="1">
        <tr>
            <th>Plan Name</th>
            <th>Amount</th>
            <th>Interval</th>
        </tr>
        <?php foreach ($dataPricing['data'] as $plan): ?>
            <tr>
<td><?php echo $plan['name']; ?></td>
<td><?php echo $plan['amount'] / 100; ?> NGN</td>
<td><?php echo $plan['interval']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>