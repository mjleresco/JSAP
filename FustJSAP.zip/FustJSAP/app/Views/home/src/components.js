import { Text, Button, ImageButton, DropdownMenu, Input, ElementHelper, applyStyles } from './widgets.js';

class Toolbar {
    constructor(customStyles = {}, justifyContent = 'flex-start') {
        this.toolbar = ElementHelper.createElement('div');
        applyStyles(this.toolbar, {
            display: 'flex',
            justifyContent: justifyContent,
            alignItems: 'center',
            ...customStyles
        });
    }

    addElement(element) {
        this.toolbar.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.toolbar);
    }
}

class Navbar {
    constructor(customStyles = {}, justifyContent = 'flex-start') {
        this.navbar = ElementHelper.createElement('nav');
        applyStyles(this.navbar, {
            display: 'flex',
            justifyContent: justifyContent,
            alignItems: 'center',
            ...customStyles
        });
    }

    addElement(element) {
        this.navbar.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.navbar);
    }
}

class Form {
    constructor({ method, action, customStyles = {} }) {
        this.form = ElementHelper.createElement('form');
        this.form.method = method;
        this.form.action = action;
        applyStyles(this.form, {
            display: 'flex',
            flexDirection: 'column',
            gap: '1px', 
            ...customStyles
        });
    }

    addElement(element) {
        this.form.appendChild(element);
    }

    addErrorMessageDiv(customStyles = {}) {
        this.errorMessageDiv = ElementHelper.createElement('div');
        applyStyles(this.errorMessageDiv, {
            border: '1px solid #a00',
            display: 'none',
            borderRadius: '5px',
            padding: '10px',
            ...customStyles});
        this.form.appendChild(this.errorMessageDiv);
    }
    
    showErrorMsgDiv() {
        this.errorMessageDiv.style.display = 'block';
    }

    submitForm(callback) {
        this.form.onsubmit = async (event) => {
            event.preventDefault();
            const formData = new FormData(this.form);
            try {
                const response = await fetch(this.form.action, {
                    method: this.form.method,
                    body: formData
                });
                const result = await response.json();
                callback(result.success, result);
                if (!result.success) {
                    this.errorMessageDiv.innerText = result.message;
                }
            } catch (error) {
                console.error('Form submission error:', error);
                callback(false, {'message': 'Form not submitted: Error occur while submitting it!\n'+
                                 'Check console to view the error.'
                                });
            }
        };
    }

    render(parent) {
        parent.appendChild(this.form);
    }
}

class Header {
    constructor(customStyles = {}) {
        this.header = ElementHelper.createElement('header');
        applyStyles(this.header, customStyles);
        applyStyles(this.header, {
            display: 'flex',
            flexDirection: 'column',
            gap: '1px', 
            top: 0,
            width: '100%',
            zIndex: 100,
        });
    }

    addElement(element) {
        this.header.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.header);
    }
    
    getElement() {
        return this.header;
    }
}

class Main {
    constructor(customStyles = {}) {
        this.main = ElementHelper.createElement('main');
        applyStyles(this.main, {...customStyles});
        
    }

    addElement(element) {
        this.main.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.main);
    }
    
    getElement() {
        return this.main;
    }
}

class Footer {
    constructor(customStyles = {}) {
        this.footer = ElementHelper.createElement('footer');
        applyStyles(this.footer, { width: '100wv', bottom: '0', ...customStyles});
    }

    addElement(element) {
        this.footer.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.footer);
    }
    
    getElement() {
        return this.footer;
    }
}

class Container {
    constructor(customStyles = {}) {
        this.container = ElementHelper.createElement('div');
        applyStyles(this.container, {
            display: 'block',
            margin: '0',
            padding: '5px',
            ...customStyles
        });
    }

    addElement(element) {
        this.container.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.container);
    }

    getElement() {
        return this.container;
    }
}

class Row {
    constructor(customStyles = {}) {
        this.row = ElementHelper.createElement('div');
        applyStyles(this.row, { display: 'flex', flexWrap: 'wrap', margin: '0', padding: '0', ...customStyles });
    }

    addElement(element) {
        this.row.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.row);
    }

    getElement() {
        return this.row;
    }
}

class Column {
    constructor(size, customStyles = {}) {
        this.col = ElementHelper.createElement('div');
        const percentage = (size / 12) * 100;
        applyStyles(this.col, { flex: `0 0 ${percentage}%`, maxWidth: `${percentage}%`, margin: '0', padding: '0', ...customStyles });
    }

    addElement(element) {
        this.col.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.col);
    }

    getElement() {
        return this.col;
    }
}

class Tab {
    constructor(tabs, 
            customStyles = {
                currentTab: {
                    
                },
                buttons: {
                    
                },
                button: {
                    
                }
                
            }) {
        this.tabContainer = ElementHelper.createElement('div');
        this.tabButtons = ElementHelper.createElement('div');
        this.tabContents = ElementHelper.createElement('div');
        this.tabs = tabs;
        this.activeTabIndex = 0;
        this.customStyles = customStyles;

        applyStyles(this.tabContainer, { ...this.customStyles['container'] });
        applyStyles(this.tabButtons, { display: 'flex', justifyContent: 'space-around', backgroundColor: '#aaaaaa', color: '#fff', padding: '5px', ...this.customStyles['buttons'] });
        applyStyles(this.tabContents, {  ...this.customStyles['contents'] });

        tabs.forEach((tab, index) => {
            var button = ElementHelper.createElement('div');
            var label = tab.label;
            button.appendChild(label);
            button.dataset.index = index;
            applyStyles(button, { padding: '7px 7px 0px 7px', backgroundColor: 'rgb(0, 0, 0, 0.0)', color: '#000', ...customStyles['button']});
            button.addEventListener('click', () => this.showTab(index));
            this.tabButtons.appendChild(button);

            const content = ElementHelper.createElement('div');
            content.appendChild(tab.content);
            applyStyles(content, { display: 'none', ...this.customStyles['content'] });
            this.tabContents.appendChild(tab.content);
        });

        this.tabContainer.appendChild(this.tabButtons);
        this.tabContainer.appendChild(this.tabContents);

        if (tabs.length > 0) {
            this.showTab(0);
        }
    }

    showTab(index) {
        const contents = this.tabContents.children;
        const buttons = this.tabButtons.children;
        this.activeTabIndex = index;

        for (let i = 0; i < contents.length; i++) {
                contents[i].style.display = i === index ? 'block' : 'none';
                buttons[i].style.fontWeight = i === index ? 'bold' : 'normal';
            if(i == index){
                applyStyles(buttons[i], {  padding: '2px 7px 5px 7px', borderBottom: 'solid 3px #0000ff', backgroundColor: 'rgb(255, 0, 255, 0.2)', color: '#00f', ...this.customStyles['currentTab']});
            }else{
                applyStyles(buttons[i], { padding: '7px 7px 0px 7px', borderBottom: 'solid 0px #0000bb', backgroundColor: 'rgb(0, 0, 0, 0.0)', color: '#000', ...this.customStyles['button'] });   
            }
        }
    }

    getCurrentTabIndex() {
        return this.activeTabIndex;
    }

    addElement(element) {
        this.tabContainer.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.tabContainer);
    }

    getElement() {
        return this.tabContainer;
    }
}
class Table {
    constructor(headers, rows, customStyles = {}) {
        this.table = ElementHelper.createElement('table');
        applyStyles(this.table, { width: '100%', borderCollapse: 'collapse', ...customStyles.table });

        // Create table headers
        const thead = ElementHelper.createElement('thead');
        const headerRow = ElementHelper.createElement('tr');
        headers.forEach(header => {
            const th = ElementHelper.createElement('th', header);
            applyStyles(th, { padding: '5px', border: '1px solid #ddd', ...customStyles.header });
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        this.table.appendChild(thead);

        // Create table rows
        const tbody = ElementHelper.createElement('tbody');
        rows.forEach(row => {
            const tr = ElementHelper.createElement('tr');
            row.forEach(cell => {
                const td = ElementHelper.createElement('td', cell);
                applyStyles(td, { padding: '8px', border: '1px solid #ddd', ...customStyles.cell });
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
        this.table.appendChild(tbody);
    }

    addElement(element) {
        this.table.appendChild(element);
    }

    render(parent) {
        parent.appendChild(this.table);
    }

    getElement() {
        return this.table;
    }
}

export { Toolbar, Navbar, Form, Header, Main, Footer, Container, Row, Column, Tab, Table };