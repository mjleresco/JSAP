class ElementHelper {
    static createElement(tag, content = '') {
        const element = document.createElement(tag);
        element.innerHTML = content;
        return element;
    }
}

function applyStyles(element, styles) {
    for (const [key, value] of Object.entries(styles)) {
        element.style[key] = value;
    }
}

class Text {
    constructor(content, customStyles = {}) {
        this.text = ElementHelper.createElement('span', content);
        applyStyles(this.text, customStyles);
    }

    getElement() {
        return this.text;
    }
}

class Button {
    constructor(content, onClick, customStyles = {}) {
        this.button = ElementHelper.createElement('button', content);
        applyStyles(this.button, customStyles);
        this.button.onclick = onClick;
    }

    getElement() {
        return this.button;
    }
}

class ImageButton {
    constructor(src, alt, onClick, customStyles = {}) {
        this.button = ElementHelper.createElement('button');
        const img = ElementHelper.createElement('img');
        img.src = src;
        img.alt = alt;
        this.button.appendChild(img);
        applyStyles(this.button, customStyles);
        this.button.addEventListener('click', onClick);
    }

    getElement() {
        return this.button;
    }
}

class DropdownMenu {
    constructor(content, items, {
        direction = 'down', 
        buttonStyles = {}, 
        menuStyles = {}, 
        itemStyles = {}, 
        hoverItemStyles = {},
        customStyles = {}
    } = {}) {
        this.dropdown = ElementHelper.createElement('div');
        applyStyles(this.dropdown, { position: 'relative', display: 'block', margin: '0 10px', ...customStyles });

        this.button = ElementHelper.createElement('button', content);
        this.button.onclick = () => {
            this.menu.style.display = this.menu.style.display === 'block' ? 'none' : 'block';
        };
        applyStyles(this.button, { height: '40px', cursor: 'pointer', border: '3px solid', borderRadius: '9px', ...buttonStyles });

        this.menu = ElementHelper.createElement('div');
        applyStyles(this.menu, {
            display: 'none',
            position: 'absolute',
            backgroundColor: '#f9f9f9',
            minWidth: '160px',
            boxShadow: '0px 8px 16px 0px rgba(0,0,0,0.2)',
            zIndex: 3,
            ...menuStyles
        });

        items.forEach(item => {
            const menuItem = ElementHelper.createElement('a', item.text);
            menuItem.href = item.href;
            applyStyles(menuItem, { color: 'black', padding: '12px 16px', textDecoration: 'none', display: 'block', ...itemStyles });
            menuItem.onmouseover = () => applyStyles(menuItem, hoverItemStyles);
            menuItem.onmouseout = () => applyStyles(menuItem, itemStyles);
            this.menu.appendChild(menuItem);
        });

        this.dropdown.appendChild(this.button);
        this.dropdown.appendChild(this.menu);

        // Adjust menu direction
        switch (direction) {
            case 'up':
                applyStyles(this.menu, { bottom: '100%', top: 'auto' });
                break;
            case 'left':
                applyStyles(this.menu, { left: 'auto', right: '100%' });
                break;
            case 'right':
                applyStyles(this.menu, { right: 'auto', left: '100%' });
                break;
            default:
                applyStyles(this.menu, { top: '100%', bottom: 'auto' });
                break;
        }
    }

    getElement() {
        return this.dropdown;
    }
}

class Input {
    constructor(type, name, placeholder = '', customStyles = {}) {
        this.input = ElementHelper.createElement('input');
        this.input.type = type;
        this.input.name = name;
        this.input.placeholder = placeholder;
        applyStyles(this.input, customStyles);
    }

    getElement() {
        return this.input;
    }
}

class ColorPicker {
    constructor(name, value = '', customStyles = {}) {
        this.colorPicker = ElementHelper.createElement('input');
        this.colorPicker.type = 'color';
        this.colorPicker.name = name;
        this.colorPicker.value = value;
        applyStyles(this.colorPicker, customStyles);
    }

    getElement() {
        return this.colorPicker;
    }
}

class DatePicker {
    constructor(name, value = '', customStyles = {}) {
        this.datePicker = ElementHelper.createElement('input');
        this.datePicker.type = 'date';
        this.datePicker.name = name;
        this.datePicker.value = value;
        applyStyles(this.datePicker, customStyles);
    }

    getElement() {
        return this.datePicker;
    }
}

class TimePicker {
    constructor(name, value = '', customStyles = {}) {
        this.timePicker = ElementHelper.createElement('input');
        this.timePicker.type = 'time';
        this.timePicker.name = name;
        this.timePicker.value = value;
        applyStyles(this.timePicker, customStyles);
    }

    getElement() {
        return this.timePicker;
    }
}

class CheckBox {
    constructor(name, label = '', checked = false, customStyles = {}) {
        this.cont = ElementHelper.createElement('div');
        this.checkbox = ElementHelper.createElement('input');
        this.label = ElementHelper.createElement('span', label);
        this.checkbox.type = 'checkbox';
        this.checkbox.name = name;
        this.checkbox.checked = checked;
        
        applyStyles(this.cont, customStyles);
                
        this.cont.appendChild(this.checkbox);
        this.cont.appendChild(this.label);
    }

    getElement() {
        return this.cont;
    }
}

class Radio {
    constructor(name, label = '', selecked = false, customStyles = {}) {
        this.cont = ElementHelper.createElement('div');
        this.radio = ElementHelper.createElement('input');
        this.label = ElementHelper.createElement('span', label);
        this.radio.type = 'radio';
        this.radio.name = name;
        this.radio.selecked = selecked;
        
        applyStyles(this.cont, customStyles);
                
        this.cont.appendChild(this.radio);
        this.cont.appendChild(this.label);
    }

    getElement() {
        return this.cont;
    }
}

// New UI components
class Card {
    constructor(customStyles = {}) {
        this.cardElement = ElementHelper.createElement('div');
        applyStyles(this.cardElement, { boxShadow: '0 4px 8px 0 rgba(0,0,0,0.2)', padding: '16px', ...customStyles });
    }

    addElement(element) {
        this.cardElement.appendChild(element);
    }

    getElement() {
        return this.cardElement;
    }
}

class Modal {
    constructor(content, customStyles = {}) {
        this.modalElement = ElementHelper.createElement('div');
        const modalContent = ElementHelper.createElement('div', content);
        const closeButton = ElementHelper.createElement('span', '×', { class: 'close' });

        applyStyles(this.modalElement, {
            display: 'none', position: 'static', zIndex: 1, left: 0, top: 0,
            width: '100%', height: '100%', overflow: 'auto', backgroundColor: 'rgba(0,0,0,0.4)', ...customStyles.modal
        });
        applyStyles(modalContent, {
            backgroundColor: '#fefefe', margin: '15% auto', padding: '20px', border: '1px solid #888', width: '80%', ...customStyles.content
        });
        applyStyles(closeButton, { color: '#aaa', float: 'right', fontSize: '28px', fontWeight: 'bold', cursor: 'pointer', ...customStyles.close });

        closeButton.onclick = () => {
            this.modalElement.style.display = 'none';
        };

        window.onclick = (event) => {
            if (event.target === this.modalElement) {
                this.modalElement.style.display = 'none';
            }
        };

        modalContent.appendChild(closeButton);
        this.modalElement.appendChild(modalContent);
    }

    showModal() {
        this.modalElement.style.display = 'block';
    }

    hideModal() {
        this.modalElement.style.display = 'none';
    }

    getElement() {
        return this.modalElement;
    }
}

class Alert {
    constructor(message, type = 'info', customStyles = {}) {
        this.alertElement = ElementHelper.createElement('div', message);
        const alertTypes = {
            success: { backgroundColor: '#dff0d8', color: '#3c763d' },
            info: { backgroundColor: '#d9edf7', color: '#31708f' },
            warning: { backgroundColor: '#fcf8e3', color: '#8a6d3b' },
            danger: { backgroundColor: '#f2dede', color: '#a94442' }
        };
        applyStyles(this.alertElement, { padding: '15px', marginBottom: '20px', border: '1px solid transparent', borderRadius: '4px', ...alertTypes[type], ...customStyles });
    }

    getElement() {
        return this.alertElement;
    }
}

class Badge {
    constructor(text, customStyles = {}) {
        this.badgeElement = ElementHelper.createElement('span', text);
        applyStyles(this.badgeElement, { display: 'inline-block', padding: '.25em .4em', fontSize: '75%', fontWeight: '700', lineHeight: '1', color: '#fff', textAlign: 'center', whiteSpace: 'nowrap', verticalAlign: 'baseline', borderRadius: '.25rem', backgroundColor: '#007bff', ...customStyles });
    }

    getElement() {
        return this.badgeElement;
    }
}

class ProgressBar {
    
    constructor(progress, customStyles = {}) {
        this.progressElement = ElementHelper.createElement('div');
        this.progressBar = ElementHelper.createElement('div');

        applyStyles(this.progressElement, { width: '100%', backgroundColor: '#e9ecef', borderRadius: '.25rem', ...customStyles.container });
        applyStyles(this.progressBar, { width: `${progress}%`, height: '16px', backgroundColor: '#007bff', borderRadius: '.25rem', ...customStyles.bar });

        this.progressElement.appendChild(this.progressBar);
    }
    
    setProgress(progress){
        this.progressBar.style.width = `${progress}%`;
    }
    
    getElement() {
        return this.progressElement;
    }
}

class Link {
    constructor(text, href, customStyles = {}) {
        this.linkElement = ElementHelper.createElement('a', text, { href });
        applyStyles(this.linkElement, customStyles);
    }

    getElement() {
        return this.linkElement;
    }
}

class Seekbar {
    constructor(min, max, value, customStyles = {}, onSeek = null) {
        this.seekbar = ElementHelper.createElement('input' );
        this.seekbar.type = 'range';
        this.seekbar.min = min;
        this.seekbar.max = max;
        this.seekbar.value = value;
        
        applyStyles(this.seekbar, {
            width: '100%',
            height: '5px',
            ...customStyles.seekbar
        });
        
        if(onSeek){
            //Called onSeek(value) on class construction
            onSeek(this.seekbar.value);
            
            //on value change statement
            this.seekbar.addEventListener('input', () => {
                onSeek(this.seekbar.value);
            });
        }
    }
    
    getElement() {
        return this.seekbar;
    }
}
export { Text, Input, Radio, CheckBox, ColorPicker, DatePicker, TimePicker, Button, ImageButton, DropdownMenu, Card, Modal, Alert, Badge, ProgressBar, Link, Seekbar, applyStyles, ElementHelper };