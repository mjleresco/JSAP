<?php
/*
use Fust\App\Auth\AuthService;
AuthService::authenticate('/login');
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toolbar, Navbar, and AJAX Example</title>
</head>
<body>
    
    <script type="module" src="FustJSAP/app/Views/home/home.js"></script>
</body>
</html>








