import { Text, Input, DatePicker, TimePicker, ColorPicker, CheckBox, Radio, Button, ImageButton, DropdownMenu, Card, Modal, Alert, Badge, ProgressBar, Link, Seekbar, applyStyles } from './fust-js-bundle.js';
import { Toolbar, Navbar, Form, Header, Main, Footer, Container, Row, Column, Tab, Table } from './fust-js-bundle.js';

document.addEventListener('DOMContentLoaded', () => {
const body = document.body;
body.style.margin = 0;
body.style.padding = 0;
body.style.fontFamily = 'Arial, sans-serif';
body.style.lineHeight = '1.6';
body.style.backgroundColor = '#f4f4f4';

const header = new Header({
    backgroundColor: '#050',
    color: '#fff',
    height: '100px',
    position: 'fixed',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    top: 0,
    width: '100%',
    zIndex: 100
});

const toolbar = new Toolbar({
    height: '50px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%'
});

toolbar.addElement(new Text('Leresco', { color: '#fff', fontSize: '24px' }).getElement());
toolbar.addElement(new Button('Home', () => alert('Home clicked'), { color: '#fff', backgroundColor: '#444' }).getElement());
toolbar.addElement(new ImageButton('image.png', 'Image Button', () => alert('Image Button clicked'), { width: '24px', height: '24px' }).getElement());

const dropdownMenu = new DropdownMenu('&#9776;', [
    { text: 'Item 1', href: '/item1' },
    { text: 'Item 2', href: '/item2' }
], {
    direction: 'left',
    buttonStyles: { fontSize: '25px', padding: '0 5px', backgroundColor: '#555', color: '#fff' },
    menuStyles: { backgroundColor: '#444' },
    itemStyles: { color: '#fff' },
    hoverItemStyles: { backgroundColor: '#666' }
});

toolbar.addElement(dropdownMenu.getElement());

header.addElement(toolbar.toolbar);
header.render(body);

const navbar = new Navbar({
    backgroundColor: '#070',
    color: '#fff',
    height: '50px',
    marginLeft: '0px',
    paddingLeft: '0px',
    width: '100%'
});

const nb_col1 = new Column(2);
const nb_col2 = new Column(10, { overflow: 'auto'});

nb_col1.addElement(new DropdownMenu('&#9776;', [
    { text: 'Link 2', href: '#' },
    { text: 'Link 3', href: '#' }
], {
    direction: 'down',
    buttonStyles: { fontSize: '25px', padding: '0 5px', backgroundColor: '#555', color: '#fff' },
    menuStyles: { backgroundColor: '#444' },
    itemStyles: { color: '#fff' },
    hoverItemStyles: { backgroundColor: '#666' },
    customStyles: { marginLeft: '0px', marginRight: '10px', padding: '0px' }
}).getElement());
nb_col2.addElement(new Link('Home', '/home', { marginRight: '10px', color: '#fff', fontSize: '18px' }).getElement());
nb_col2.addElement(new Link('Tutorials', '/tutorials', { marginRight: '10px', color: '#fff', fontSize: '18px' }).getElement());
nb_col2.addElement(new Link('Tutorials', '/tutorials', { marginRight: '10px', color: '#fff', fontSize: '18px' }).getElement());
nb_col2.addElement(new Link('News', '/news', { marginRight: '10px', color: '#fff', fontSize: '18px' }).getElement());
nb_col2.addElement(new Link('About', '/about', { marginRight: '10px', color: '#fff', fontSize: '18px' }).getElement());
navbar.addElement(nb_col1.getElement());
navbar.addElement(nb_col2.getElement());
header.addElement(navbar.navbar);
header.render(body);

const main = new Main({
    margin: '0',
    padding: '0px',
    marginTop: header.header.offsetHeight+'px',
    backgroundColor: '#2f2'
});

const container = new Container();
const container0 = new Container();
const row = new Row();
const row0 = new Row();
const col1 = new Column(6);
const col10 = new Column(6);
const col2 = new Column(6);
const col20 = new Column(6);

const welcomeText = new Text('Welcome to the Toolbar, Navbar, and Form Example',
                                { fontSize: '32px' }).getElement();
const welcomeText0 = new Text('Welcome to the Toolbar, Navbar, and Form Example',
                                { fontSize: '32px' }).getElement();
col1.addElement(welcomeText);
col10.addElement(welcomeText0);

const loremText = new Text('Scroll down to see the header stay in place.\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris scelerisque...', { marginTop: '20px' }).getElement();
const loremText0 = new Text('Scroll down to see the header stay in place.\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris scelerisque...', { marginTop: '20px' }).getElement();
const loremText1 = new Text('Scroll down to see the header stay in place.\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris scelerisque...', { marginTop: '20px' }).getElement();
col2.addElement(loremText);
col20.addElement(loremText0);

row.addElement(col1.getElement());
row0.addElement(col10.getElement());
row.addElement(col2.getElement());
row0.addElement(col20.getElement());
container.addElement(row.getElement());
container0.addElement(row0.getElement());
main.addElement(container.getElement());

// Creating a form
const formContainer = new Container({ marginTop: '20px' });
const formRow = new Row();
const formCol = new Column(12);

const form = new Form({
    method: 'POST',
    action: '/form-submit',
    customStyles: {
        maxWidth: '300px',
        margin: '10px',
        padding: '0 10px',
        boxSizing: 'border-box',
        paddingBottom: '30px',
        backgroundColor: '#99f',
        border: '1px solid #ccc',
        borderRadius: '8px'
    }
});

form.addElement(new Text('<center><h2>Log in</h2></center>', { display: 'block', margin: '0' }).getElement());


form.addErrorMessageDiv({ color: 'red', margin: '10px 0'});
const today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format

form.addElement(new Text('Date:', { display: 'block', marginBottom: '0' }).getElement());
form.addElement(new DatePicker('date', today, {
    width: '100%',
    boxSizing: 'border-box',
    display: 'block',
    padding: '10px',
    marginBottom: '10px',
    borderRadius: '4px',
    border: '1px solid #ccc'
}).getElement());

form.addElement(new Text('Time:', { display: 'block', marginBottom: '0' }).getElement());
form.addElement(new TimePicker('time', '12:00', {
    width: '100%',
    boxSizing: 'border-box',
    display: 'block',
    padding: '10px',
    marginBottom: '10px',
    borderRadius: '4px',
    border: '1px solid #ccc'
}).getElement());

form.addElement(new Text('Color:', { display: 'block', marginBottom: '0' }).getElement());
form.addElement(new ColorPicker('color', '#1aa11a', {
    boxSizing: 'border-box',
    display: 'block',
    width: '100%',
    height: '40px',
    marginBottom: '10px',
    borderRadius: '4px',
    border: '1px solid #ccc'
}).getElement());

form.addElement(new Text('Username:', { display: 'block', marginBottom: '0' }).getElement());
form.addElement(new Input('text', 'username', 'Enter your username', {
    width: '100%',
    boxSizing: 'border-box',
    padding: '10px',
    marginBottom: '10px',
    borderRadius: '4px',
    border: '1px solid #ccc'
}).getElement());

form.addElement(new Text('Password:', { display: 'block', marginBottom: '0' }).getElement());
form.addElement(new Input('password', 'password', 'Enter your password', {
    width: '100%',
    boxSizing: 'border-box',
    padding: '10px',
    margin: '0 auto',
    marginBottom: '10px',
    borderRadius: '4px',
    border: '1px solid #ccc'
}).getElement());

var checkBox = new CheckBox('save', 'Remember me', true, {
    margin: '10px 10px'
});

form.addElement(checkBox.getElement());
form.addElement(new Radio('gender', 'Male', true, {
    margin: '5px 0'
}).getElement());

form.addElement(new Radio('gender', 'Female', true, {
    margin: '5px 0'
}).getElement());

form.addElement(new Input('submit', 'submit', 'Log in', {
    width: '100%',
    boxSizing: 'border-box',
    backgroundColor: '#00a',
    color: '#fff',
    marginTop: '15px',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '4px'
}).getElement());

form.submitForm((success, result) => {
    if (success) {
        alert(result.message);
    } else {
        form.errorMessageDiv.innerText = result.message;
        form.showErrorMsgDiv();
    }
});

formCol.addElement(form.form);
formRow.addElement(formCol.getElement());
formContainer.addElement(formRow.getElement());
//main.addElement(formContainer.getElement());

// Creating tabs
const tabContainer = new Container({ marginTop: '20px' });
const tabRow = new Row();
const tabCol = new Column(12);

const tabBtn1 = new Text('Users').getElement();
const tabBtn2 = new Text('Admins').getElement();
const tabBtn3 = new Text('Profile').getElement();

const tabs = new Tab([
    { label: tabBtn1, content: form.form },
    { label: tabBtn2, content: container0.getElement() },
    { label: tabBtn3, content: loremText1 }
], {
    container: { padding: 'auto', marginTop: '20px' },
    button: { cursor: 'pointer' },
    contents: { flex: '0 0 100%', margin: '0 auto', padding: '0 auto', backgroundColor: '#fff', border: '1px solid #ccc' },
    content: {}
});

tabCol.addElement(tabs.getElement());
tabRow.addElement(tabCol.getElement());
tabContainer.addElement(tabRow.getElement());
main.addElement(tabContainer.getElement());

    // Creating a card example
    const cardContainer = new Container({ marginTop: '20px' });
    const cardRow = new Row();
    const cardCol = new Column(12);

    const card = new Card();
    
    const c_text = new Text('Welcome to the Toolbar, Navbar, and Form Example', { fontSize: '32px' }).getElement();
    
    card.addElement(c_text);
    
    cardCol.addElement(card.getElement());
    cardRow.addElement(cardCol.getElement());
    cardContainer.addElement(cardRow.getElement());
    var mcard = cardContainer;
    main.addElement(cardContainer.getElement());

    // Creating a seekbar example
    const seekbarContainer = new Container({ marginTop: '20px' });
    const seekbarRow = new Row();
    const seekbarValueCol = new Column(12);
    const seekbarCol = new Column(12);

    const seekbarValue = new Text('Current Value: 0', { fontSize: '16px', marginBottom: '10px' }).getElement();

    const seekbar = new Seekbar(0, 100, 30, {},
        (value) => {
            seekbarValue.innerText = `Current Value: ${value}`;
        }
    );

    seekbarValueCol.addElement(seekbarValue);
    seekbarCol.addElement(seekbar.getElement());
    seekbarRow.addElement(seekbarValueCol.getElement());
    seekbarRow.addElement(seekbarCol.getElement());
    seekbarContainer.addElement(seekbarRow.getElement());
    main.addElement(seekbarContainer.getElement());

    // Creating a progress bar example
    const progressBarContainer = new Container({ marginTop: '20px' });
    const progressBarRow = new Row();
    const progressBarCol = new Column(12);

    const progressBar = new ProgressBar(50, {
        container: { width: '100%', backgroundColor: '#ddd' },
        progress: { height: '20px', backgroundColor: '#4caf50' }
    });

    progressBarCol.addElement(progressBar.getElement());
    progressBarRow.addElement(progressBarCol.getElement());
    progressBarContainer.addElement(progressBarRow.getElement());
    main.addElement(progressBarContainer.getElement());

    // Render the main content
    main.render(body);

    // Create and render the footer
    const footer = new Footer({
        backgroundColor: '#050',
        color: '#fff',
        padding: '10px',
        textAlign: 'center'
    });

    footer.addElement(new Text('© 2024 Your Company', { color: '#fff' }).getElement());
    footer.render(body);
});