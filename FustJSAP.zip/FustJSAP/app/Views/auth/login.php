<?php
//use Fust\App\Auth\AuthService;
//AuthService::is_authenticated('/');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <?php /* if(!empty($data)): ?>
        <p style="color: red;"><?php echo print_r($data); ?></p>
    <?php endif;*/ ?>
    <form action="/login" method="POST">
        <label for="email">Email:</label><br />
        <input type="email" name="email" id="email" required>
        <br><br />
        <label for="password">Password:</label><br />
        <input type="password" name="password" id="password" required>
        <br /><br />
        <button type="submit">Login</button>
    </form>
</body>
</html>