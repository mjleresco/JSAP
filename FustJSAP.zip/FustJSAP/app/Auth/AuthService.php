<?php

namespace Fust\App\Auth;

use Fust\PHP\Utils\UserUtils;
use Fust\PHP\Core\Utils;

class AuthService {
    
    public static function authenticate($url){
        $auth = UserUtils::authenticateUser();
        if(!$auth) {
            Utils::redirect($url);
        }
    }
    
    public static function is_authenticated($url){
        $auth = UserUtils::authenticateUser();
        if($auth){
            Utils::redirect($url);
        }
    }
}

?>