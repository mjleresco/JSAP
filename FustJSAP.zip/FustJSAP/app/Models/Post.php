<?php

namespace Fust\App\Models;

use Fust\PHP\Core\Model;

class Post extends Model{
    
    public function __construct(){
        parent::__construct();
        
        $this->table = "posts";
        $this->primaryKey = "post_id";
        
        $this->fields = [
            'post_id' => ['type' => 'INT',          'nullable' => false, 'unique' => false,  'extra' => 'AUTO_INCREMENT'],
            'user_id' => ['type' => 'INT(11)',      'nullable' => false, 'unique' => false, 'extra' => ''],
            'title'   => ['type' => 'VARCHAR(255)', 'nullable' => false, 'unique' => false, 'extra' => ''],
            'content' => ['type' => 'TEXT',         'nullable' => false, 'unique' => false, 'extra' => '']
        ];
        
        $this->foreignKeys = [
            'user_id' => ['users', 'id', 'CASCADE', 'CASCADE']
        ];
        
    }
}

?>