<?php

namespace Fust\App\Models;

use Fust\PHP\Core\Model;

class UserRole extends Model{
    
    public function __construct(){
        parent::__construct();
        
        $this->table = 'user_roles';
        $this->primaryKey = 'id';
        
        $this->fields = [
            'id'      => ['type' => 'INT(11)',      'nullable' => false, 'unique' => false,  'extra' => 'AUTO_INCREMENT'],
            'user_id' => ['type' => 'INT(11)',      'nullable' => false, 'unique' => false,  'extra' => ''],
            'role'    => ['type' => 'VARCHAR(50)',  'nullable' => false, 'unique' => false,  'extra' => '']
        ];
        
        $this->foreignKeys = [
            'user_id' => ['users', 'id', 'CASCADE', 'CASCADE']
        ];
        
    }
    
}

?>