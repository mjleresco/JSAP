<?php

namespace Fust\App\Models;


use Fust\PHP\Core\Model;
use Fust\PHP\Core\Utils;
use Fust\PHP\Utils\UserUtils;

class User extends Model{
    
    protected $userUtils;
    
    public function __construct(){
        parent::__construct();
        
        $this->userUtils = new UserUtils($this->connection);
        
        $this->table = 'users';
        $this->primaryKey = 'id';
        
        $this->fields = [
            'id' => [
                'type' => 'INT(11)',
                'nullable' => false,
                'unique' => true,
                'extra' => 'AUTO_INCREMENT'
            ],
            'username' => [
                'type' => 'VARCHAR(50)',
                'nullable' => false,
                'unique' => true,
                'extra' => ''
            ],
            'password' => [
                'type' => 'VARCHAR(255)',
                'nullable' => false,
                'unique' => false,
                'extra' => ''
            ],
            'email' => [
                'type' => 'VARCHAR(100)',
                'nullable' => false,
                'unique' => false,
                'extra' => ''
            ],
            'gender' => [
                'type' => 'ENUM("male", "female")',
                'nullable' => false,
                'unique' => false,
                'extra' => ''
            ],
            'active' => [
                'type' => 'ENUM("yes", "no")',
                'nullable' => false,
                'unique' => false,
                'extra' => ''
            ],
            'last_seen' => [
                'type' => 'DATETIME',
                'nullable' => false,
                'unique' => false,
                'extra' => ''
            ],
            'created_at' => [
                'type' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
                'nullable' => false,
                'unique' => false,
                'extra' => ''
            ]
        ];
        
    }
    
    public function create($username, $email, $password, $gender){
        $data = [
            'username' => $username,
            'email' => $email,
            'password' => $password,
            'gender' => $gender
        ];
        $this->userUtils->registerUser($this->table, $data, 'email', 'password');
    }
    
    public function varifyEmail($email){
        
    }
    
    public function login($email, $password){
        
        $login = $this->userUtils->loginUser($this->table, 'email', $email, 'password', $password);
        return $login;
    }
    
    public function resetPassword($email, $newPassword){
        
    }
    
    public function logout(){
        $logout = $this->userUtils->logoutUser();
        if($logout){
            Utils::redirect('/login');
        }
    }
}


?>