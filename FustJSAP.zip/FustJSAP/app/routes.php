<?php


// Example route definitions
$app->router->add('GET', '/', HomeController::class, 'index');
$app->router->add('GET', '/login', UserController::class, 'showLoginForm');
$app->router->add('POST', '/login', UserController::class, 'login');
$app->router->add('GET', '/register', UserController::class, 'showRegistrationForm');
$app->router->add('POST', '/register', UserController::class, 'register');
$app->router->add('POST', '/logout', UserController::class, 'logout');
$app->router->add('POST', '/form-submit', AjaxController::class, 'handle');
$app->router->add('GET', '/logout', UserController::class, 'logout');

$app->router->add('GET', '/airtime/prices', AirtimeController::class, 'prices');

// Example AJAX route
$app->router->add('POST', '/ajax/some-action', AjaxController::class, 'someAction');

?>