<?php

namespace Fust\App\Controllers\AirtimePurchase;

use Fust\Core\Controller;

class AirtimeController extends Controller{
    public function prices(){
        $this->view->render('pricing', ['message' => 'Welcome to Fust PHP Framework!']);
    }
}

?>