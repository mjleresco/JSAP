<?php

namespace Fust\App\Controllers;

use Fust\Core\Controller;

class HomeController extends Controller{
    public function index(){
        $this->view->render('home.index', ['message' => 'Welcome to Fust PHP Framework!']);
    }
}

?>