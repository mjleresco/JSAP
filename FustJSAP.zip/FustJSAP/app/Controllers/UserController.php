<?php

namespace Fust\App\Controllers;

use Fust\PHP\Core\Utils;
use Fust\PHP\Core\Controller;
use Fust\App\Models\User;

class UserController extends Controller {
    
    public function showLoginForm() {
        $this->view->render('auth.login');
    }

    public function login() {
        $username = $_POST['email'];
        $password = $_POST['password'];
        $_user = new User();
        $user = $_user->login($username, $password);
        if($user['success']){
            Utils::redirect('/');
        }else{
            $this->view->render('auth.login', $user);
        }
    }
    
    public function showRegistrationForm() {
        $this->view->render('auth.register');
    }
    
    public function register() {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $gender = 'male';
    
        $user = new User();
        
        $user->create($username, $email, $password, $gender);
    
        header('Location: /login');
        exit;
    }
    
    public function logout() {
        $_user = new User();
        $user = $_user->logout();
        exit;
    }
}

?>