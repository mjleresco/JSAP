<?php

namespace Fust\App\Controllers;

use Fust\Core\Utils;
use Fust\Core\Controller;
use Fust\App\Models\User;

class LogoutController extends Controller
{
    public function logout()
    {
        $_user = new User();
        $user = $_user->logout();
        exit;
    }
}

?>