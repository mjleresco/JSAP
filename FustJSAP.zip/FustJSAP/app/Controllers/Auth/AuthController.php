<?php

namespace Fust\App\Controllers\Auth;

use Fust\Core\Controller;
use Fust\Core\Auth\AuthService;

class AuthController extends Controller
{
    protected $authService;

    public function __construct()
    {
        parent::__construct();
        $this->authService = new AuthService($this->databaseUtils);
    }

    public function loginForm()
    {
        $this->view->render('auth.login');
    }

    public function login()
    {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $userId = $this->authService->authenticate($username, $password);

        if ($userId) {
            // Login successful, redirect or set session
            $_SESSION['user_id'] = $userId;
            header('Location: /');
        } else {
            // Login failed, handle error
            echo "Login failed";
        }
    }

    public function registerForm()
    {
        $this->view->render('auth.register');
    }

    public function register()
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];

        $this->authService->register($username, $password, $email);

        // Registration successful, redirect or set session
        header('Location: /login');
    }

    public function logout()
    {
        $this->authService->logout();
        session_destroy();
        header('Location: /');
    }
}

?>