<?php

namespace Fust\App\Controllers\Auth;

use Fust\Core\UserUtils;
use Fust\Core\Controller;
use Fust\App\Models\User;

class RegisterController extends Controller
{
    public function showRegistrationForm()
    {
        $this->view->render('auth.register');
    }

    public function register()
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $gender = $_POST['gender'];

        $user = new User();
        
        $user->create($username, $email, $password, $gender);

        header('Location: /login');
        exit;
    }
}

?>