<?php

namespace Fust\App\Controllers\Auth;

use Fust\Core\Utils;
use Fust\Core\Controller;
use Fust\App\Models\User;

class LoginController extends Controller {
    
    public function showLoginForm(){
        $this->view->render('auth.login');
    }

    public function login() {
        $username = $_POST['email'];
        $password = $_POST['password'];
        $_user = new User();
        $user = $_user->login($username, $password);
        if($user['success']){
            Utils::redirect('/');
        }else{
            $this->view->render('auth.login', $user);
        }
    }
}

?>